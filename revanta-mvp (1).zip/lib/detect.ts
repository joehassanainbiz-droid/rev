import OpenAI from "openai";
import { z } from "zod";
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
export const Result = z.object({
  is_opportunity: z.boolean(),
  score: z.number().int().min(0).max(100),
  confidence: z.enum(["Low", "Medium", "High"]),
  signals: z.array(z.object({ signal: z.string(), quote: z.string(), points: z.number() })),
  estimated_value: z.number().nullable(), // null = unknown; never invent
  value_basis: z.string(),
  next_action: z.string(),
  followup: z.string(),
});
const SYSTEM = `You find unfinished sales opportunities in a business's customer conversation.
Only use what is in the conversation. Every signal MUST include an exact quote from the customer's messages; if you cannot quote it, omit it.
Never invent customer statements, budgets, prices or outcomes. If deal value is not stated, set estimated_value to null and explain in value_basis.
Score 0-100 from: purchase intent, price talk, availability/booking, quote request, urgency, recency, whether the business's last reply went unanswered. Be conservative; casual questions (opening hours) are NOT opportunities.
The follow-up must be short and human, reference only real conversation details, use [Your name] placeholders, and promise nothing the business hasn't.
Return JSON only.`;
export async function detect(conv: { msgs: { date: string; dir: string; text: string }[]; industry?: string }) {
  const transcript = conv.msgs.map(m => `[${m.date}] ${m.dir === "in" ? "CUSTOMER" : "BUSINESS"}: ${m.text}`).join("\n");
  const r = await client.chat.completions.create({
    model: process.env.OPENAI_MODEL ?? "gpt-4o-mini",
    response_format: { type: "json_object" },
    messages: [{ role: "system", content: SYSTEM }, { role: "user", content: `Industry: ${conv.industry ?? "unknown"}\nToday: ${new Date().toISOString().slice(0, 10)}\n\n${transcript}` }],
  });
  const parsed = Result.safeParse(JSON.parse(r.choices[0].message.content ?? "{}"));
  if (!parsed.success) return null;
  const res = parsed.data;
  const inbound = conv.msgs.filter(m => m.dir === "in").map(m => m.text.toLowerCase()).join(" ");
  res.signals = res.signals.filter(s => inbound.includes(s.quote.toLowerCase().trim())); // drop hallucinated quotes
  return res.signals.length ? res : null;
}
