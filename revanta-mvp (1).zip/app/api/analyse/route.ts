import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import Papa from "papaparse";
import { detect } from "@/lib/detect";
export const maxDuration = 300;
const MAX_ROWS = 5000, MAX_BYTES = 5_000_000;
export async function POST(req: Request) {
  const token = req.headers.get("authorization")?.replace("Bearer ", "");
  if (!token) return NextResponse.json({ error: "unauthorised" }, { status: 401 });
  // User-scoped client: RLS applies, so users can only write to their own org.
  const sb = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, { global: { headers: { Authorization: `Bearer ${token}` } } });
  const form = await req.formData(); const file = form.get("file") as File; const org_id = String(form.get("org_id"));
  if (!file || file.size > MAX_BYTES || !file.name.endsWith(".csv")) return NextResponse.json({ error: "CSV up to 5MB required" }, { status: 400 });
  const { data: mem } = await sb.from("organization_members").select("org_id").eq("org_id", org_id).maybeSingle();
  if (!mem) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const rows = Papa.parse<Record<string, string>>(await file.text(), { header: true, skipEmptyLines: true, transformHeader: h => h.trim().toLowerCase() }).data.slice(0, MAX_ROWS);
  const by = new Map<string, any>();
  for (const r of rows) {
    if (!r.customer || !r.date || !r.message || isNaN(Date.parse(r.date))) continue;
    const c = by.get(r.customer) ?? { name: r.customer, source: r.source || "CSV", industry: r.industry, value: Number(r.value) || null, msgs: [] };
    c.msgs.push({ date: r.date, dir: /^o/i.test(r.direction) ? "out" : "in", text: r.message.slice(0, 4000) }); by.set(r.customer, c);
  }
  let found = 0;
  for (const c of by.values()) {
    c.msgs.sort((a: any, b: any) => +new Date(a.date) - +new Date(b.date));
    const { data: cust } = await sb.from("customers").upsert({ org_id, name: c.name }, { onConflict: "org_id,name" }).select().single();
    const { data: conv } = await sb.from("conversations").insert({ org_id, customer_id: cust!.id, source: c.source, industry: c.industry, declared_value: c.value }).select().single();
    await sb.from("messages").insert(c.msgs.map((m: any) => ({ org_id, conversation_id: conv!.id, sent_at: m.date, direction: m.dir, body: m.text })));
    const res = await detect(c); if (!res?.is_opportunity) continue;
    await sb.from("opportunities").insert({ org_id, conversation_id: conv!.id, score: res.score, confidence: res.confidence, est_value: c.value ?? res.estimated_value, value_source: c.value ? "from your data" : res.estimated_value ? "AI estimate" : "unknown", signals: res.signals, next_action: res.next_action, followup_draft: res.followup });
    found++;
  }
  await sb.from("audit_logs").insert({ org_id, action: "csv_analysed", detail: { rows: rows.length, customers: by.size, found } });
  return NextResponse.json({ customers: by.size, opportunities: found });
}
