"use client";
import { useEffect, useState, useCallback } from "react";
import { sb } from "@/lib/supabase";
const money = (n: number) => "$" + Math.round(n || 0).toLocaleString("en-AU");
function Ring({ v }: { v: number }) {
  const c = 2 * Math.PI * 22, col = v >= 75 ? "#34d399" : v >= 50 ? "#f2b84b" : "#8d93a5";
  return (<svg width="60" height="60" viewBox="0 0 60 60" aria-label={`Score ${v} of 100`}><circle cx="30" cy="30" r="22" fill="none" stroke="rgba(255,255,255,.1)" strokeWidth="5" />
    <circle cx="30" cy="30" r="22" fill="none" stroke={col} strokeWidth="5" strokeLinecap="round" strokeDasharray={`${c * v / 100} ${c}`} transform="rotate(-90 30 30)" />
    <text x="30" y="35" textAnchor="middle" fontSize="16" fontWeight="700" fill="#f4f5f8">{v}</text></svg>);
}
export default function Home() {
  const [session, setSession] = useState<any>(null), [ready, setReady] = useState(false);
  const [org, setOrg] = useState<{ id: string; name: string; commission_pct: number } | null>(null);
  const [opps, setOpps] = useState<any[]>([]), [busy, setBusy] = useState(false), [msg, setMsg] = useState("");
  const [email, setEmail] = useState(""), [pw, setPw] = useState(""), [biz, setBiz] = useState("");
  const [drafts, setDrafts] = useState<Record<string, string>>({}), [drag, setDrag] = useState(false);
  useEffect(() => {
    sb.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true); });
    const { data: sub } = sb.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);
  const load = useCallback(async () => {
    const { data: m } = await sb.from("organization_members").select("organizations(id,name,commission_pct)").limit(1).maybeSingle();
    const o = (m as any)?.organizations ?? null; setOrg(o); if (!o) return;
    const { data } = await sb.from("opportunities").select("*, conversations(source, customers(name)), followups(sent_at), revenue_events(amount, attributed, attribution_reason)").order("score", { ascending: false });
    setOpps(data ?? []);
  }, []);
  useEffect(() => { if (session) load(); }, [session, load]);
  async function auth(kind: "in" | "up") {
    setMsg(""); const r = kind === "up" ? await sb.auth.signUp({ email, password: pw }) : await sb.auth.signInWithPassword({ email, password: pw });
    if (r.error) setMsg(r.error.message); else if (kind === "up" && !r.data.session) setMsg("Check your email to confirm, then log in.");
  }
  async function makeOrg() { const { error } = await sb.rpc("create_org", { n: biz, ind: null }); if (error) setMsg(error.message); else load(); }
  async function upload(f: File) {
    setBusy(true); setMsg("Analysing your conversations. This can take a minute.");
    const fd = new FormData(); fd.append("file", f); fd.append("org_id", org!.id);
    const r = await fetch("/api/analyse", { method: "POST", body: fd, headers: { Authorization: `Bearer ${session.access_token}` } });
    const j = await r.json(); setMsg(r.ok ? `Found ${j.opportunities} opportunities across ${j.customers} customers.` : j.error); setBusy(false); load();
  }
  const text = (o: any) => drafts[o.id] ?? o.followup_draft ?? "";
  async function send(o: any) {
    await sb.from("followups").insert({ org_id: org!.id, opportunity_id: o.id, body: text(o), sent_at: new Date().toISOString() });
    await sb.from("opportunities").update({ status: "sent" }).eq("id", o.id); load();
  }
  async function sale(o: any) {
    const a = Number(prompt("Sale amount ($)", String(o.est_value ?? ""))); if (!(a > 0)) return;
    const { error } = await sb.from("revenue_events").insert({ org_id: org!.id, opportunity_id: o.id, amount: a, occurred_at: new Date().toISOString() });
    if (error) setMsg(error.message); else { await sb.from("opportunities").update({ status: "won" }).eq("id", o.id); load(); }
  }
  if (!ready) return null;
  if (!session) return (
    <main className="mx-auto max-w-6xl px-5">
      <nav className="flex items-center justify-between py-6"><b className="tracking-[.22em]">REVANTA</b><a href="#start" className="btn ghost">Log in</a></nav>
      <section className="grid items-center gap-10 py-10 md:grid-cols-2 md:py-20">
        <div><h1 className="text-5xl font-semibold leading-[1.02] md:text-7xl">Your inbox is leaking money.</h1>
          <p className="mute mt-6 max-w-md text-lg">REVANTA finds customers who wanted to buy from you but never got followed up, shows what each could be worth, and writes the follow-up.</p>
          <div className="mt-8 flex gap-3"><a href="#start" className="btn">Find my lost revenue</a><a href="#how" className="btn ghost">See how it works</a></div></div>
        <div className="stage relative mx-auto h-80 w-full max-w-md md:h-96" aria-hidden><div className="stack absolute left-1/4 top-1/4 h-40 w-56">
          {[0, 1, 2].map(i => <div key={i} className="plate" style={{ transform: `translateZ(${i * 34}px)`, opacity: 1 - i * .18 }}>{i === 2 && <div><div className="mute text-xs">Demo illustration</div><div className="text-2xl font-bold">$650,000</div><div className="text-xs">Score 94</div></div>}</div>)}</div></div>
      </section>
      <section id="how" className="grid gap-4 py-10 md:grid-cols-3">
        {[["Upload", "Past enquiries as a CSV. No inbox access needed."], ["See the money", "Every opportunity has a score, a value, and the customer's own words as evidence."], ["Follow up", "Edit the drafted message, send it, record the sale. Attribution is tracked."]].map(([a, b]) =>
          <div key={a} className="glass p-6"><h3 className="text-lg font-semibold">{a}</h3><p className="mute mt-2 text-sm">{b}</p></div>)}
      </section>
      <section id="start" className="mx-auto max-w-sm py-16"><div className="glass space-y-3 p-6"><h2 className="text-xl font-semibold">Get started</h2>
        <input className="input" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
        <input className="input" type="password" placeholder="Password" value={pw} onChange={e => setPw(e.target.value)} />
        <div className="flex gap-2"><button className="btn" onClick={() => auth("up")}>Sign up</button><button className="btn ghost" onClick={() => auth("in")}>Log in</button></div>
        <p className="text-sm text-amber-300">{msg}</p></div></section>
    </main>);
  if (!org) return (
    <main className="mx-auto max-w-sm px-5 pt-24"><div className="glass space-y-3 p-6"><h2 className="text-xl font-semibold">Name your business</h2>
      <input className="input" value={biz} onChange={e => setBiz(e.target.value)} placeholder="Acme Homes" />
      <button className="btn" disabled={!biz} onClick={makeOrg}>Create workspace</button><p className="text-sm text-amber-300">{msg}</p></div></main>);
  const rec = opps.flatMap(o => o.revenue_events ?? []).filter((r: any) => r.attributed).reduce((s: number, r: any) => s + Number(r.amount), 0);
  const pot = opps.filter(o => o.status !== "won").reduce((s, o) => s + Number(o.est_value || 0), 0);
  const hot = opps.filter(o => o.score >= 75 && o.status === "detected").length;
  return (
    <main className="mx-auto max-w-5xl space-y-6 px-4 py-5 md:px-8">
      <header className="flex items-center justify-between"><div><b className="tracking-[.22em]">REVANTA</b> <span className="mute">· {org.name}</span></div><button className="btn ghost" onClick={() => sb.auth.signOut()}>Sign out</button></header>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[["Potential revenue", money(pot)], ["Recovered", money(rec)], ["Hot, not yet chased", hot], [`Our fee (${org.commission_pct}%)`, money(rec * org.commission_pct / 100)]].map(([a, b]) =>
          <div key={String(a)} className="glass p-4"><div className="mute text-xs">{a}</div><div className="mt-1 text-2xl font-semibold md:text-3xl">{b}</div></div>)}
      </div>
      <label onDragOver={e => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={e => { e.preventDefault(); setDrag(false); e.dataTransfer.files[0] && upload(e.dataTransfer.files[0]); }}
        className={"glass block cursor-pointer p-6 text-center " + (drag ? "!border-[var(--acc)]" : "")}>
        <div className="font-semibold">{busy ? "Analysing…" : "Drop a CSV here, or tap to choose"}</div>
        <div className="mute mt-1 text-sm">Columns: customer, date, direction (in/out), message. Optional: source, industry, value.</div>
        <input type="file" accept=".csv" hidden disabled={busy} onChange={e => e.target.files?.[0] && upload(e.target.files[0])} />
        {msg && <div className="mt-2 text-sm text-amber-300">{msg}</div>}</label>
      {!opps.length && <div className="glass p-8 text-center"><h3 className="font-semibold">No opportunities yet</h3><p className="mute text-sm">Upload a CSV to see who you never followed up.</p></div>}
      {opps.map(o => { const ev = (o.revenue_events ?? [])[0]; const sent = (o.followups ?? []).some((f: any) => f.sent_at); return (
        <article key={o.id} className="glass space-y-3 p-5">
          <div className="flex items-center gap-4"><Ring v={o.score} />
            <div className="min-w-0 flex-1"><div className="truncate font-semibold">{o.conversations?.customers?.name}</div><div className="mute text-sm">{o.conversations?.source} · confidence {o.confidence}</div></div>
            <div className="text-right"><div className="text-xl font-semibold">{money(o.est_value)}</div><div className="mute text-xs">{o.value_source}</div></div></div>
          <div className="flex flex-wrap gap-2">{(o.signals ?? []).map((s: any, i: number) => <span key={i} className="chip" title={s.signal}>“{s.quote}”</span>)}</div>
          <textarea className="input min-h-24" value={text(o)} disabled={sent} onChange={e => setDrafts({ ...drafts, [o.id]: e.target.value })} aria-label="Follow-up message" />
          <div className="flex flex-wrap items-center gap-2">
            {!sent && <><button className="btn ghost" onClick={() => navigator.clipboard.writeText(text(o))}>Copy</button><button className="btn acc" onClick={() => send(o)}>Mark as sent</button></>}
            {sent && !ev && <button className="btn acc" onClick={() => sale(o)}>Record sale</button>}
            {ev && <span className={ev.attributed ? "text-emerald-300" : "mute"}>{money(ev.amount)} · {ev.attribution_reason}</span>}
          </div></article>); })}
    </main>);
}
