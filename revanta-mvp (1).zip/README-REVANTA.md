# REVANTA: runnable full-stack MVP (typechecks clean; not yet tested against a live Supabase/OpenAI)

Loop: sign up -> create workspace -> upload CSV -> AI finds opportunities -> mark follow-up sent -> record sale -> attribution + fee calculated.

## Run it (about 15 minutes)
1. Install Node.js 20+ (nodejs.org).
2. Create a free project at supabase.com. In the SQL editor, paste and run `supabase/schema.sql`.
3. In Supabase: Authentication > Providers > Email > turn OFF "Confirm email" while testing.
4. Copy `.env.example` to `.env.local`. Fill in the Supabase URL + anon key (Project Settings > API) and your OpenAI key (platform.openai.com).
5. In this folder run: `npm install` then `npm run dev`, open http://localhost:3000
6. Sign up, name your business, upload a CSV (columns: customer, date, direction (in/out), message; optional source, industry, value).

## Deploy
Push to GitHub, import at vercel.com, add the same 4 env vars, deploy.

## Known gaps
No Stripe billing, Gmail/Outlook, team invites, or notifications yet. Sending is manual (copy the message yourself, then mark sent).
Test tenant isolation with two accounts before using real customer data, and get privacy/legal advice first.
