-- REVANTA multi-tenant schema. Run in Supabase SQL editor. Every table carries org_id; RLS enforces isolation.
create extension if not exists pgcrypto;
create table organizations(id uuid primary key default gen_random_uuid(), name text not null, industry text, commission_pct numeric default 10, attribution_days int default 60, created_at timestamptz default now());
create table organization_members(org_id uuid references organizations on delete cascade, user_id uuid references auth.users on delete cascade, role text default 'member', primary key(org_id,user_id));
create table customers(id uuid primary key default gen_random_uuid(), org_id uuid not null references organizations on delete cascade, name text not null, email text, unique(org_id,name));
create table conversations(id uuid primary key default gen_random_uuid(), org_id uuid not null references organizations on delete cascade, customer_id uuid references customers on delete cascade, source text, industry text, declared_value numeric, created_at timestamptz default now());
create table messages(id uuid primary key default gen_random_uuid(), org_id uuid not null references organizations on delete cascade, conversation_id uuid references conversations on delete cascade, sent_at timestamptz not null, direction text check(direction in('in','out')), body text not null);
create table opportunities(id uuid primary key default gen_random_uuid(), org_id uuid not null references organizations on delete cascade, conversation_id uuid references conversations on delete cascade, score int, confidence text, est_value numeric, value_source text, signals jsonb, next_action text, followup_draft text, status text default 'detected', detected_at timestamptz default now(), unique(conversation_id));
create table followups(id uuid primary key default gen_random_uuid(), org_id uuid not null references organizations on delete cascade, opportunity_id uuid references opportunities on delete cascade, body text, sent_at timestamptz, customer_replied_at timestamptz);
create table revenue_events(id uuid primary key default gen_random_uuid(), org_id uuid not null references organizations on delete cascade, opportunity_id uuid references opportunities on delete cascade, amount numeric not null check(amount>0), occurred_at timestamptz not null, attributed boolean, attribution_reason text, created_at timestamptz default now());
create table audit_logs(id bigserial primary key, org_id uuid, user_id uuid, action text, detail jsonb, at timestamptz default now());
create or replace function is_member(o uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from organization_members where org_id=o and user_id=auth.uid()) $$;
do $$ declare t text; begin
 foreach t in array array['customers','conversations','messages','opportunities','followups','revenue_events','audit_logs'] loop
  execute format('alter table %I enable row level security',t);
  execute format('create policy tenant_all on %I for all using(is_member(org_id)) with check(is_member(org_id))',t);
 end loop; end $$;
alter table organizations enable row level security; alter table organization_members enable row level security;
create policy org_read on organizations for select using(is_member(id));
create policy mem_read on organization_members for select using(user_id=auth.uid());
-- Attribution (server-side, not client-trusted): attributed iff follow-up sent, sale after send, within window.
create or replace function attribute_sale() returns trigger language plpgsql security definer set search_path=public as $$
declare s timestamptz; d int; begin
 select min(sent_at) into s from followups where opportunity_id=new.opportunity_id and sent_at is not null;
 select attribution_days into d from organizations where id=new.org_id;
 new.attributed := s is not null and new.occurred_at>=s and new.occurred_at<=s+make_interval(days=>d);
 new.attribution_reason := case when s is null then 'no follow-up sent' when new.occurred_at<s then 'sale predates follow-up' when not new.attributed then 'outside attribution window' else 'flagged + followed up + sale in window' end;
 return new; end $$;
create trigger trg_attr before insert on revenue_events for each row execute function attribute_sale();
-- Sign-up helper: creates an org and makes the caller its owner (RLS blocks doing this directly).
create or replace function create_org(n text, ind text) returns uuid language plpgsql security definer set search_path=public as $$
declare o uuid; begin
 if auth.uid() is null then raise exception 'not signed in'; end if;
 insert into organizations(name,industry) values(n,ind) returning id into o;
 insert into organization_members(org_id,user_id,role) values(o,auth.uid(),'owner'); return o; end $$;
